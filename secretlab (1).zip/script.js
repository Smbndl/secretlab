function revealMessage() {
  const message = document.getElementById('message');
  message.classList.remove('hidden');
  document.getElementById('revealButton').style.display = 'none';
}
